package ut2;

import java.io.IOException;
import java.util.Scanner;

public class Practica_multiproceso_I {
//	private static Scanner SC = new Scanner(System.in);

	public static void main(String[] args) throws IOException, InterruptedException {
		Scanner sc = new Scanner(System.in);
		
		proceso(sc);
		
		sc.close();
	}

	public static void proceso(Scanner sc) throws IOException {
		int n = 0;
		String palabra = "";
		System.out.println("\n\tDime que opción eliges:" + "\n----------------------------------------"
				+ "\n\t1. Apagar\n" + "\t2. Reiniciar\n" + "\t3. Suspender\n");
		n = Integer.parseInt(sc.nextLine());

		switch (n) {
		case 1:
			palabra = "-s";
			ruta(palabra, tiempo(sc));
			cancelar(sc);
			break;
		case 2:
			palabra = "-r";
			ruta(palabra);
			cancelar(sc);
			break;
		case 3:
			palabra = "-h";
			ruta(palabra);
			cancelar(sc);
			break;
		default:
			System.out.println("Elige los números que hay");
			break;
		}	

	}
	
	public static void cancelar(Scanner sc) throws IOException {
		String n = "";
		System.out.println("\n\tQuieres cancelar el proceso: " + "\n------------------------------------------"
				+ "\n\tSi\n" +  "\tNo\n");
		n = sc.nextLine();
		if (n.equalsIgnoreCase("si")) {
			ruta();
			System.out.println("Se ha cancelado.");
		}
	}
	public static void ruta(String p, String t) throws IOException {
		ProcessBuilder pb = new ProcessBuilder("C:\\Windows\\System32\\shutdown ", p, "-t", t);
		Process p1 = null;
		p1 = pb.start();
	}
	
	public static void ruta(String p) throws IOException {
		ProcessBuilder pb = new ProcessBuilder("C:\\Windows\\System32\\shutdown ", p);
		Process p1 = null;
		p1 = pb.start();
	}
	
	public static void ruta() throws IOException {
		ProcessBuilder pb = new ProcessBuilder("C:\\Windows\\System32\\shutdown ", "-a");
		Process p1 = null;
		p1 = pb.start();
	}

	public static String tiempo(Scanner sc) {
		String n = "";
		System.out.println("Cuando tiempo quieres esperar a la acción.");
		n = sc.nextLine();
		return n;
	}
	
	
	
}
